#include <iostream>

/**
* @brief Returns the successor of a given number.
*
* Adds one to the given number.
*
* @param num non-positive integer.
* @return size_t The successor of num.
*/
size_t succ(size_t num){
    // method : add one to the given number
    return num+1;
}

/**
 * @brief Returns the predecessor of a given number.
 *
 * Recursively increments candidate until its successor equals the number.
 *
 * @param num positive integer.
 * @param cand The candidate value (default is 0).
 * @return size_t The predecessor of num.
 */
size_t pred(size_t num,size_t cand = 0){
    // method : recursively increment candidate until its successor equals the number
    // base case : pred(1) => 0
    // reccursive call : pred(n,cand) => pred(n,succ(cand))
    if(succ(cand) == num) return cand;
    return pred(num,succ(cand));
}

/**
 * @brief Subtracts one number from another recursively.
 *
 * Recursively decrements both numbers until the second is zero.
 *
 * @param m The minuend. Atleast one more than num2.
 * @param n The subtrahend. Atmost one less than num1.
 * @return size_t The result of num1 - num2.
 */
size_t minus(size_t m,size_t n){
    // method : recursively decrement both numbers until second is zero
    // base case : minus(m,n):m<n => 0
    //             minus(m,0): => m
    // reccursive call : minus(m,n) => minus(pred(m),pred(n))
    if(m < n) return 0;
    if(n <= 0) return m;
    return minus(pred(m),pred(n));
}

// main function
int main(){
    // declaring input variables
    size_t num1,num2;

    // prompting user to enter first number
    std::cout << "Enter the first non-negative number \n(should be greater than second number) : " ;
    // taking input
    std::cin >> num1;
    
    // prompting user to enter second number
    std::cout << "\nEnter the second non-negative number \n(should be less than first number) : " ;
    // taking input
    std::cin >> num2;

    // calculating return of subtraction and displaying result
    std::cout << "\nSecond number subtracted from first is : " << minus(num1,num2) << std::endl;
    
    return 0; // exiting program
}

// ? QUESTIONS : 
// What is the simplest possible case for subtraction?
// ! ANSWER : 
// simplest case is when first number is less than second then we just return 0, oe when second number is 0 ; then we just return first number
// When does the recursion stop?
// ! ANSWER : 
// reccursion stops when the second number reaches 0 while decreasing